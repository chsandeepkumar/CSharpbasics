﻿namespace WindowsAppGridView
{
    public class SalesData
    {
        public string BusinessEntityID { get; set; }
         public string  TerritoryID { get; set; }
        public string  SalesQuota { get; set; }
        public string  Bonus { get; set; }
        public string  CommissionPct { get; set; }
        public string SalesYTD { get; set; }
    }
}
